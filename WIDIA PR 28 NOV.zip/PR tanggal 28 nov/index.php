<?php

error_reporting(0);
session_start();
if(isset($_POST["login"])) {
    $user = $_POST["username"];
    $pass = $_POST["password"];

    if($user == "widia" || $pass == "123"){
        session_start();

        $_SESSION['berhasil']=true;
        header("location:index2.php");
    }else{
        $salah = "<p style='color:red; text-align:center;'> username dan password salah</p> ";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form login</title>

<style>
body, h1, h2, p, input, button {
    margin: 0;
    padding: 0;
}

body {
    font-family: Arial, sans-serif;
    background-image:url(1.jpg);
    background-size:cover;
}

.container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
   
}

.formlogin {
    background-image:url(1.jpg);
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.foto img {
    width: 80px; 
    margin-bottom: 10px;
}

.formlogin h1 {
    font-size: 20px;
    text-align: center;
    margin-bottom: 20px;
}

.formlogin form {
    display: flex;
    flex-direction: column;
}

input {
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    padding: 10px;
    background-color: red;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.button:hover {
    background-color: red;
}

.lupa {
    margin-top: 10px;
    text-align: center;
}

.lupa a {
    margin-right: 20px;
    text-decoration: none;
    color: #333;
}

@media (max-width: 600px) {
    .formlogin {
        width: 80%;
    }
}
</style>
</head>
<body>
    <div class="container">
        <div class="formlogin">
            <div class="foto"><img src=""><h1>silahkan login</h1></div>

<?php echo $salah; ?>
            <form action="" method="post">
                <input type="text" placeholder="username" name="username"><br>
                <input type="text" placeholder="password" name="password"><br>
                <button type="submit" name="login">SUBMIT</button>
</form>
<div class="lupa">
    <a href="#"><span>lupa password ? </span></a>
    <a href="#"><span>belum punya akun ?</span></a>

</div>
        </div>
    </div>
</body>
</html>